import logo from './logo.svg';
import { useState, useEffect } from 'react';
import gamesJson from './schedule';
import './App.css';

function App() {
  const titleName = (id) => {
    const titles = {
      1: 'Preseason',
      2: 'Regular Season',
      3: 'Playoffs',
    };
    return titles[id];
  }

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <div>
          Hola Mundo
        </div>

        <div className="games-container">
          { gamesJson.map((game, index) => {
            return (
                <div className="game" key={`key-${index}`}>
                  <h4>NFL { titleName(game.SeasonType)}</h4>
                  <div>
                    <div>
                      <div>
                        <img src={`https://assets.fanzeem.com/teams/images/${game.AwayTeam}.png`} alt=""/>
                        <span>{game.AwayTeam}</span>
                      </div>
                      <div>
                        <img src={`https://assets.fanzeem.com/teams/images/${game.HomeTeam}.png`} alt=""/>
                        <span>{game.HomeTeam}</span>
                      </div>
                    </div>
                    <div>
                      <span>Aug 5</span>
                      <span>6:30 PM</span>
                    </div>
                  </div>
                </div>
            )
          }) }

        </div>
      </header>
    </div>
  );
}

export default App;
